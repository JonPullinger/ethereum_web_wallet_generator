# Required
- Docker
- [wtfcmd](https://wtf.blunt.sh)