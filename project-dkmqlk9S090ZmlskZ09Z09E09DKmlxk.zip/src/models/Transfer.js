const { Model } = require('../app/bookshelf')

module.exports = Model.extend({
	tableName: 'transfers',
})
