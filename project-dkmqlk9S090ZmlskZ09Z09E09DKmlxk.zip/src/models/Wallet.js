const { Model } = require('../app/bookshelf')
const Transfer = require('./Transfer')

module.exports = Model.extend({
	tableName: 'wallets',
	hasTimestamps: true,
	lastSentTransfer() {
		return this.hasOne(Transfer, 'from', 'public_key')
	},
	lastReceivedTransfer() {
		return this.hasOne(Transfer, 'to', 'public_key')
	},
})
