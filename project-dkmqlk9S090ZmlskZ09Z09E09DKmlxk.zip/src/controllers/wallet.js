const route = require('koa-route')
const Wallet = require('../models/Wallet')

module.exports = [
    /** Create new wallet */
    route.post('/api/wallet', async (ctx) => {
        let body = ctx.request.body
        if (!body.publicKey) throw new Error('Missing public key')

        // Insert
        let wallet = await Wallet.forge({
            public_key: body.publicKey,
        }).save()
        ctx.body = { id: wallet.id }
    }),

    /** List wallets */
    route.get('/wallets', async (ctx) => {
        ctx.body = `
        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
        <style>
        body { font-family: Lato; font-size:16px; letter-spacing:.5px; }
        table { margin:auto; margin-top:60px; }
        td, th { text-align:left; padding: 10px 15px; font-weight:normal; }
        thead { background: rgba(0,0,0,.05); }
        </style>
        <title>Wallets</title>
        <table cellspacing="0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Public Key</th>
                    <th>ETH</th>
                    <th>TTU</th>
                    <th>Last sent transfer</th>
                    <th></th>
                    <th>Last received transfer</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>`
        
        let wallets = await Wallet.fetchAll({
            withRelated: ['lastSentTransfer', 'lastReceivedTransfer'],
        })
        wallets.each(wallet => {
            ctx.body += `<tr>
                <td>${wallet.id}</td>
                <td>${wallet.get('public_key')}</td>
                <td>${wallet.get('balance')}</td>
                <td>${wallet.get('balance_erc20')}</td>`
            
            let tx = wallet.related('lastSentTransfer')
            if (tx.id) {
                ctx.body += `<td>${tx.get('to')}</td><td>${tx.get('amount')}</td>`
            } else {
                ctx.body += '<td></td><td></td>'
            }

            tx = wallet.related('lastReceivedTransfer')
            if (tx.id) {
                ctx.body += `<td>${tx.get('to')}</td><td>${tx.get('amount')}</td>`
            } else {
                ctx.body += '<td></td><td></td>'
            }

            ctx.body += '</tr>'
        })

        ctx.body += '</tbody></table>'
    }),

    // temp page to test
    route.get('/refresh', async (ctx) => {
        const { reloadAll } = require('../app/ether')
        await reloadAll()
        ctx.body = '<title>Refresh Balances</title><div style="font-size:40px; padding:14px 18px;">✅</div>'
    })
]