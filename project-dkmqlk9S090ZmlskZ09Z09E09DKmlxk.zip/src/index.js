// Main script
require('./app/koa')
require('./app/ether')

// Dev code
if (process.env.NODE_ENV === 'developement') {
	// Restart on change
	const chokidar = require('chokidar')
	const watcher = chokidar.watch(__dirname, {
		ignored: /^\./,
		ignoreInitial: true,
		persistent: true,
		usePolling: true,
	})
	watcher.on('all', (ev, path) => {
		console.log(path, ev)
		process.exit(1)
	})
}