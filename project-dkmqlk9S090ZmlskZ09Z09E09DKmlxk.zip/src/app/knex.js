const config = require('../configs/database')
const knex = require('knex')

module.exports = knex(config)