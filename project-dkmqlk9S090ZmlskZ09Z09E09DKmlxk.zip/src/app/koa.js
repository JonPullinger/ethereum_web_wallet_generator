const Koa = require('koa')
const send = require('koa-send')
const fs = require('fs')
const bodyParser = require('co-body')

const app = module.exports = new Koa

// Error handling
app.use(async (ctx, next) => {
    try {
        await next()
    } catch (err) {
        //TODO: error by content type
        // Simple error format
        ctx.status = err.status || 500
        if (typeof err.toJson === 'function') {
            ctx.body = error.toJson()
        } else {
            ctx.body = { error: err.message }
        }
    }
})

// Performance log
app.use(async (ctx, next) => {
	const start = Date.now()
	await next()
	const ms = Date.now() - start
	console.log(`${ctx.method} ${ctx.originalUrl} - ${ctx.status} - ${ms}`)
})

// APIs
app.use(async (ctx, next) => {
    if (/\/api\//i.test(ctx.url) && !['GET', 'HEAD', 'OPTIONS'].includes(ctx.method)) {
        // Prevent CSRF attacks
        if (!ctx.is('application/json')) {
            throw new Error('Content-type not allowed')
        }
        
        // Parse body
        ctx.request.body = await bodyParser.json(ctx.req, { limit: '5kb' })
    }
    await next()
})

// Require all controllers
let controllers = fs.readdirSync(__dirname + '/../controllers')
for (let i = 0, n = controllers.length; i < n; i++) {
    let controller = controllers[i]
    if (!/\.js$/.test(controller)) continue
    
    let middlewares = require('../controllers/' + controller)
    if (!Array.isArray(middlewares)) middlewares = [middlewares]
    
    for (let i = 0, l = middlewares.length; i < l; i++) {
        app.use(middlewares[i])
    }
}

// Static files
const sendOption = {
    root: __dirname + '/../static',
}
app.use(async (ctx, next) => {
    let done = false
    if (ctx.method === 'HEAD' || ctx.method === 'GET') {
        try {
            let path = ctx.path
            if (path === '/') path = 'index.html'
            done = await send(ctx, path, sendOption)
        } catch (err) {
            if (err.status !== 404) {
                throw err
            }
        }
    }
    if (!done) {
        await next()
    }
})

app.listen(80, () => console.log('Listening'))

// Handle stop signal
process.on('SIGINT', () => app.close())