const ethers = require('ethers')
const WalletModel = require('../models/Wallet')
const TransferModel = require('../models/Transfer')

const NETWORK = 'homestead'
const INFURA_APIKEY = 'TODO:Infura'
const ETHERSCAN_APIKEY = 'TODO:Etherscan'
const TATATU_CONTRACT = '0x9cda8a60dd5afa156c95bd974428d91a0812e054'	// Test: '0xf230b790e05390fc8295f4d3f60332c93bed42e2'
const DECIMALS = 18														// Test: 6
// Test:
//const TATATU_CONTRACT = '0xf230b790e05390fc8295f4d3f60332c93bed42e2'
//const DECIMALS = 6

// Reload all balances every SECURITY_RELOAD ms
const SECURITY_RELOAD = 24 * 60 * 60 * 1000

const ERC20_ABI = [
	{
		constant: true,
		inputs: [{ name: '_owner', type: 'address' }],
		name: 'balanceOf',
		outputs: [{ name: 'balance', type: 'uint256' }],
		payable: false,
		type: 'function'
	},
	{
		anonymous: false,
		inputs: [
			{
				indexed: true,
				name: '_from',
				type: 'address'
			},
			{
				indexed: true,
				name: '_to',
				type: 'address'
			},
			{
				indexed: false,
				name: '_value',
				type: 'uint256'
			}
		],
		name: 'Transfer',
		type: 'event'
	},
]

// Provider INFUA, backed by Etherscan
const infuraProvider = new ethers.providers.InfuraProvider(NETWORK, INFURA_APIKEY)
const etherscanProvider = new ethers.providers.EtherscanProvider(NETWORK, ETHERSCAN_APIKEY)
const provider = new ethers.providers.FallbackProvider([
	infuraProvider,
	etherscanProvider
])

// Tatatu money
const contract = new ethers.Contract(TATATU_CONTRACT, ERC20_ABI, provider)

// Reload one wallet
const reloadWallet = async (wallet) => {
	// ETH balance
	let balance = await provider.getBalance(wallet.attributes.public_key)
	wallet.set('balance', ethers.utils.formatEther(balance))

	// ERC20 balance
	balance = await contract.balanceOf(wallet.attributes.public_key)
	wallet.set('balance_erc20', ethers.utils.formatUnits(balance, DECIMALS))

	// Save
	wallet.save()
}

// Reload all balances
const reload = async () => {
	// Foreach pages
	let nb_pages = 1
	let page = 1
	while (page <= nb_pages) {
		let results = await WalletModel.forge().orderBy('-updated_at').fetchPage({
			pageSize: 1000,
			page,
		})
		nb_pages = results.pagination.pageCount
		page++

		// Foreach wallets
		for (let wallet of results.models) {
			await reloadWallet(wallet)
		}
	}
	setTimeout(() => reload(), SECURITY_RELOAD)
}
reload()

// Detect transfers
contract.ontransfer = (from, to, amount) => {
	// Save transaction
	amount = ethers.utils.formatUnits(amount, DECIMALS)
	TransferModel.forge({ from, to, amount }).save()

	// Relaod balances
	WalletModel.forge().query(knex => knex.whereIn('public_key', [from, to])).fetchAll().then(wallets => {
		for (let wallet of wallets) {
			reloadWallet(wallet)
		}
	})
}

// Exports
exports.reloadAll = reload
exports.reloadWallet = reloadWallet