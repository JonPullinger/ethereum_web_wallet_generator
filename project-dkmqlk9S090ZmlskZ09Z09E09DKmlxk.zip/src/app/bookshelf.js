const knex = require('./knex')

module.exports = require('bookshelf')(knex)
module.exports.plugin('pagination')